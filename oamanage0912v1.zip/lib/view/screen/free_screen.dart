import 'package:flutter/material.dart';

class FreeScreen extends StatelessWidget {
  const FreeScreen({super.key});
  @override
  Widget build(BuildContext context) => const Center(child: Text('자유게시판 (샘플)'));
}
