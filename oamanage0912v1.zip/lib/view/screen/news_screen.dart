// news_screen.dart
import 'package:flutter/material.dart';
class NewsScreen extends StatelessWidget {
  const NewsScreen({super.key});
  @override
  Widget build(BuildContext context) => const Center(child: Text('뉴스 목록 (샘플)'));
}
