// notice_screen.dart
import 'package:flutter/material.dart';
class NoticeScreen extends StatelessWidget {
  const NoticeScreen({super.key});
  @override
  Widget build(BuildContext context) => const Center(child: Text('공지/제휴 (샘플)'));
}
