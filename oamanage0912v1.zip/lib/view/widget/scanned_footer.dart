import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../provider/scan_provider.dart';

/// 전역 하단에 최근 스캔 결과를 고정 표시해주는 푸터
class ScannedFooter extends StatelessWidget {
  const ScannedFooter({super.key});

  @override
  Widget build(BuildContext context) {
    final scan = context.watch<ScanProvider>();
    final code = scan.lastCode;

    return Material(
      elevation: 8,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Row(
          children: [
            Icon(
              code == null ? Icons.qr_code_scanner : Icons.check_circle,
              size: 20,
              color: code == null ? Colors.grey : (scan.isReregister ? Colors.orange : Colors.green),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                code == null
                    ? '스캔 대기 중… (Scan waiting)'
                    : '[${scan.isReregister ? "재등록" : "신규"}] ${scan.lastCode}',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  color: code == null ? Colors.black54 : Colors.black87,
                ),
              ),
            ),
            if (code != null) ...[
              const SizedBox(width: 8),
              Text(_fmtTime(scan.lastAt), style: const TextStyle(fontSize: 12, color: Colors.black54)),
              const SizedBox(width: 8),
              TextButton(
                onPressed: () => context.read<ScanProvider>().clearLast(),
                child: const Text('지우기'),
              ),
            ],
          ],
        ),
      ),
    );
  }

  String _fmtTime(DateTime? dt) {
    if (dt == null) return '';
    final hh = dt.hour.toString().padLeft(2, '0');
    final mm = dt.minute.toString().padLeft(2, '0');
    final ss = dt.second.toString().padLeft(2, '0');
    return '$hh:$mm:$ss';
  }
}
