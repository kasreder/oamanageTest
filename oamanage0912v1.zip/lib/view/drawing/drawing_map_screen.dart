// lib/view/drawing/drawing_map_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../provider/drawing_provider.dart';
import '../../provider/asset_provider.dart';
import '../../model/drawing.dart';

/// ✅ 격자 고정 크기(px).
/// - 예) 50 으로 두면 '50x50 px' 셀(고정 간격)
/// - 유동(컨테이너 + 최대 1920x1080 범위에 맞춰 cols/rows로 균등 분할)으로 바꾸려면 null 로.
///   ex) const double? kFixedCellSizePx = null;
const double? kFixedCellSizePx = 50; // ← 여기만 바꾸면 모드 전환 끝!

class DrawingMapScreen extends StatefulWidget {
  const DrawingMapScreen({super.key, required this.drawingId});
  final String drawingId;

  @override
  State<DrawingMapScreen> createState() => _DrawingMapScreenState();
}

class _DrawingMapScreenState extends State<DrawingMapScreen> {
  bool showMarkers = true;

  @override
  Widget build(BuildContext context) {
    final dp = context.watch<DrawingProvider>();
    final ap = context.watch<AssetProvider>();
    final Drawing? d = dp.getById(widget.drawingId);

    if (d == null) {
      return const Center(child: Text('도면을 찾을 수 없습니다.'));
    }

    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  '${d.building} · ${d.floor}  |  ${d.title}',
                  style: Theme.of(context).textTheme.titleLarge,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Row(
                children: [
                  const Text('마커 표시'),
                  Switch(
                    value: showMarkers,
                    onChanged: (v) => setState(() => showMarkers = v),
                  ),
                ],
              ),
              const SizedBox(width: 8),
              _GridControl(d: d),
              const SizedBox(width: 8),
              OutlinedButton.icon(
                onPressed: () => _showAllAssets(context, d),
                icon: const Icon(Icons.list),
                label: const Text('배치 자산 목록'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Expanded(
            child: _DrawingCanvas(
              d: d,
              showMarkers: showMarkers,
              assetProvider: ap,
            ),
          ),
        ],
      ),
    );
  }

  void _showAllAssets(BuildContext context, Drawing d) {
    final dp = context.read<DrawingProvider>();
    final ap = context.read<AssetProvider>();
    final ids = dp.allAssetIds(d.id);
    final assets = ids.map((id) => ap.getById(id)).whereType<dynamic>().toList();

    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (_) => Padding(
        padding: const EdgeInsets.all(12),
        child: assets.isEmpty
            ? const Center(child: Text('배치된 자산이 없습니다.'))
            : ListView.separated(
          itemCount: assets.length,
          separatorBuilder: (_, __) => const Divider(height: 1),
          itemBuilder: (_, i) {
            final a = assets[i];
            return ListTile(
              leading: const Icon(Icons.inventory_2),
              title: Text(a.name),
              subtitle: Text('코드: ${a.code} · 분류: ${a.category}'),
            );
          },
        ),
      ),
    );
  }
}

class _GridControl extends StatefulWidget {
  const _GridControl({required this.d});
  final Drawing d;

  @override
  State<_GridControl> createState() => _GridControlState();
}

class _GridControlState extends State<_GridControl> {
  late int rows = widget.d.gridRows;
  late int cols = widget.d.gridCols;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const Text('행'),
        SizedBox(
          width: 56,
          child: TextFormField(
            initialValue: rows.toString(),
            textAlign: TextAlign.center,
            keyboardType: TextInputType.number,
            onFieldSubmitted: (_) => _apply(context),
            onChanged: (v) => rows = int.tryParse(v) ?? rows,
          ),
        ),
        const SizedBox(width: 8),
        const Text('열'),
        SizedBox(
          width: 56,
          child: TextFormField(
            initialValue: cols.toString(),
            textAlign: TextAlign.center,
            keyboardType: TextInputType.number,
            onFieldSubmitted: (_) => _apply(context),
            onChanged: (v) => cols = int.tryParse(v) ?? cols,
          ),
        ),
        const SizedBox(width: 8),
        FilledButton(
          onPressed: () => _apply(context),
          child: const Text('적용'),
        ),
      ],
    );
  }

  Future<void> _apply(BuildContext context) async {
    rows = rows.clamp(1, 200);
    cols = cols.clamp(1, 200);
    await context.read<DrawingProvider>().setGrid(id: widget.d.id, rows: rows, cols: cols);
  }
}

class _DrawingCanvas extends StatelessWidget {
  const _DrawingCanvas({
    required this.d,
    required this.assetProvider,
    required this.showMarkers,
  });

  final Drawing d;
  final AssetProvider assetProvider;
  final bool showMarkers;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, c) {
        return Container(
          decoration: BoxDecoration(
            color: Colors.black12,
            image: d.imageBytes != null
                ? DecorationImage(
              image: MemoryImage(d.imageBytes!),
              fit: BoxFit.contain, // 배경은 컨테이너 안에 비율 유지
              alignment: Alignment.center,
            )
                : null,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.black12),
          ),
          child: _GridOverlay(
            d: d,
            assetProvider: assetProvider,
            showMarkers: showMarkers,
          ),
        );
      },
    );
  }
}

class _GridOverlay extends StatelessWidget {
  const _GridOverlay({
    required this.d,
    required this.assetProvider,
    required this.showMarkers,
  });

  final Drawing d;
  final AssetProvider assetProvider;
  final bool showMarkers;

  static const double kMaxGridW = 1920; // ✅ 그림 최대 폭
  static const double kMaxGridH = 1080; // ✅ 그림 최대 높이

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final rows = d.gridRows;
        final cols = d.gridCols;

        // 컨테이너 실제 크기
        final contW = constraints.maxWidth;
        final contH = constraints.maxHeight;

        // ✅ 실제로 그릴 그리드(그림) 영역: 컨테이너와 1920×1080 중 더 작은 쪽으로 제한
        final gridW = contW.clamp(0, kMaxGridW);
        final gridH = contH.clamp(0, kMaxGridH);

        // 컨테이너가 gridW/H 보다 크면 가운데 정렬(양 옆/위 아래 여백)
        double offsetX = (contW - gridW) / 2;
        double offsetY = (contH - gridH) / 2;

        // ──────────────────────────────────────────────────────────────
        // ✅ [격자 크기(셀 크기) 계산의 핵심]
        // - 고정 모드(kFixedCellSizePx != null):
        //     셀 크기 = 고정값(예: 50px)
        //     gridW/gridH 범위 안에서 "몇 칸까지" 그릴지 다시 계산 → drawCols/drawRows
        // - 유동 모드(kFixedCellSizePx == null):
        //     gridW/gridH를 cols/rows로 정확히 나눠서 꽉 채움 → drawCols/drawRows = cols/rows
        // ──────────────────────────────────────────────────────────────
        late double cellW;
        late double cellH;
        late int drawCols;
        late int drawRows;

        if (kFixedCellSizePx != 50) {
          // ✅ 고정 셀 크기 모드 (예: 50 px)
          cellW = kFixedCellSizePx!;
          cellH = kFixedCellSizePx!;

          // gridW/H 안에서 반복 가능한 칸 수
          drawCols = (gridW / cellW).floor().clamp(1, cols);
          drawRows = (gridH / cellH).floor().clamp(1, rows);
        } else {
          // ✅ 유동(꽉 채우기) 모드
          cellW = gridW / cols;
          cellH = gridH / rows;
          drawCols = cols;
          drawRows = rows;
        }

        // ──────────────────────────────────────────────────────────────
        // 자산 마커 배치
        // - (r,c) 중앙 좌표 = offset + (c*cellW + cellW/2, r*cellH + cellH/2)
        // - 고정 모드에서 draw 범위를 넘어가는 셀은 스킵
        // ──────────────────────────────────────────────────────────────
        final markers = <Widget>[];
        if (showMarkers && d.cellAssets.isNotEmpty) {
          d.cellAssets.forEach((key, ids) {
            if (ids.isEmpty) return;
            final rc = _parseCellKey(key);
            if (rc == null) return;
            final r = rc.$1;
            final c = rc.$2;

            if (r >= drawRows || c >= drawCols) return; // 고정 모드에서 잘려나간 영역 스킵

            final left = offsetX + c * cellW + cellW / 2;
            final top  = offsetY + r * cellH + cellH / 2;

            markers.add(Positioned(
              left: left - 14,
              top: top - 14,
              width: 28,
              height: 28,
              child: _AssetMarker(
                count: ids.length,
                onTap: () => _openCellDialog(context, d, r, c),
              ),
            ));
          });
        }

        return Stack(
          children: [
            // 격자 그리기
            CustomPaint(
              painter: _GridPainter(
                rows: drawRows,   // ✅ 실제 그릴 칸 수(고정 모드에서는 1920×1080 내에서만)
                cols: drawCols,
                cellW: cellW,
                cellH: cellH,
                offsetX: offsetX,
                offsetY: offsetY,
              ),
              size: Size.infinite,
            ),
            // 탭 영역 (오프셋/셀 크기 고려하여 (r,c) 계산)
            Positioned.fill(
              child: _CellTappableArea(
                rows: drawRows,
                cols: drawCols,
                cellW: cellW,
                cellH: cellH,
                offsetX: offsetX,
                offsetY: offsetY,
                onCellTap: (r, c) => _openCellDialog(context, d, r, c),
              ),
            ),
            ...markers,
          ],
        );
      },
    );
  }

  (int, int)? _parseCellKey(String key) {
    try {
      final rIdx = key.indexOf('r');
      final cIdx = key.indexOf('c');
      if (rIdx != 0 || cIdx < 0) return null;
      final r = int.parse(key.substring(1, cIdx));
      final c = int.parse(key.substring(cIdx + 1));
      return (r, c);
    } catch (_) {
      return null;
    }
  }

  void _openCellDialog(BuildContext context, Drawing d, int row, int col) {
    final dp = context.read<DrawingProvider>();
    final ap = context.read<AssetProvider>();

    final key = 'r${row}c$col';
    final currentIds = List<String>.from(d.cellAssets[key] ?? const []);
    final currentAssets = currentIds.map((id) => ap.getById(id)).whereType<dynamic>().toList();

    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (sheetContext) {
        return Padding(
          padding: EdgeInsets.only(
            left: 12, right: 12, top: 12,
            bottom: MediaQuery.of(sheetContext).padding.bottom + 12,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('자리: ($row, $col)', style: Theme.of(sheetContext).textTheme.titleMedium),
              const SizedBox(height: 8),
              if (currentAssets.isEmpty)
                const ListTile(
                  leading: Icon(Icons.info_outline),
                  title: Text('배치된 자산이 없습니다.'),
                )
              else
                Flexible(
                  child: ListView.separated(
                    shrinkWrap: true,
                    itemCount: currentAssets.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (_, i) {
                      final a = currentAssets[i];
                      return ListTile(
                        leading: const Icon(Icons.inventory_2),
                        title: Text(a.name),
                        subtitle: Text('코드: ${a.code} · 분류: ${a.category}'),
                        trailing: IconButton(
                          tooltip: '제거',
                          icon: const Icon(Icons.remove_circle_outline),
                          onPressed: () async {
                            await dp.removeAssetFromCell(id: d.id, row: row, col: col, assetId: a.id);
                            await sheetContext.read<AssetProvider>().setLocationAndSync(
                              assetId: a.id, drawingId: null, row: null, col: null, drawingProvider: dp,
                            );
                            if (sheetContext.mounted) Navigator.of(sheetContext).pop();
                            _openCellDialog(context, dp.getById(d.id)!, row, col);
                          },
                        ),
                      );
                    },
                  ),
                ),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: () async {
                  final selected = await _openAssetPicker(sheetContext, ap);
                  if (selected == null) return;
                  await sheetContext.read<AssetProvider>().setLocationAndSync(
                    assetId: selected.id, drawingId: d.id, row: row, col: col, drawingProvider: dp,
                  );
                  if (sheetContext.mounted) Navigator.of(sheetContext).pop();
                  _openCellDialog(context, dp.getById(d.id)!, row, col);
                },
                icon: const Icon(Icons.add),
                label: const Text('자산 추가'),
              ),
            ],
          ),
        );
      },
    );
  }

  Future<dynamic /*Asset?*/ > _openAssetPicker(BuildContext context, AssetProvider ap) async {
    final items = ap.items;
    return showDialog(
      context: context,
      barrierDismissible: true,
      builder: (dialogContext) => AlertDialog(
        title: const Text('자산 선택'),
        content: SizedBox(
          width: 460,
          height: 400,
          child: items.isEmpty
              ? const Center(child: Text('자산 데이터가 없습니다.'))
              : ListView.separated(
            itemCount: items.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (_, i) {
              final a = items[i];
              return ListTile(
                leading: const Icon(Icons.inventory_2),
                title: Text(a.name),
                subtitle: Text('코드: ${a.code} · 분류: ${a.category}'),
                onTap: () => Navigator.of(dialogContext).pop(a),
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('닫기'),
          ),
        ],
      ),
    );
  }
}

class _AssetMarker extends StatelessWidget {
  const _AssetMarker({required this.count, required this.onTap});
  final int count;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkResponse(
        onTap: onTap,
        radius: 22,
        child: Container(
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: Colors.deepPurpleAccent.withOpacity(0.9),
            shape: BoxShape.circle,
            boxShadow: const [
              BoxShadow(color: Colors.black26, blurRadius: 6, offset: Offset(0, 2)),
            ],
          ),
          child: FittedBox(
            child: Padding(
              padding: const EdgeInsets.all(6.0),
              child: Text(
                '$count',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _GridPainter extends CustomPainter {
  _GridPainter({
    required this.rows,
    required this.cols,
    required this.cellW,
    required this.cellH,
    required this.offsetX,
    required this.offsetY,
  });

  final int rows;    // 실제 그릴 행 수(고정 모드면 1920×1080 안에서 가능한 만큼)
  final int cols;    // 실제 그릴 열 수
  final double cellW;
  final double cellH;
  final double offsetX;
  final double offsetY;

  @override
  void paint(Canvas canvas, Size size) {
    // ✅ 검정 격자(불투명). 필요하면 0x88000000 처럼 투명도를 주어도 됨.
    final gridPaint = Paint()
      ..color = const Color(0xFF000000)
      ..strokeWidth = 1.0;

    final border = Paint()
      ..color = const Color(0xFF000000)
      ..strokeWidth = 2.0;

    // 실제 그리드 영역
    final gridRect = Rect.fromLTWH(offsetX, offsetY, cols * cellW, rows * cellH);

    // 바깥 테두리
    canvas.drawRect(gridRect, border..style = PaintingStyle.stroke);

    // 세로선
    for (int c = 1; c < cols; c++) {
      final x = offsetX + c * cellW;
      canvas.drawLine(Offset(x, offsetY), Offset(x, offsetY + rows * cellH), gridPaint);
    }
    // 가로선
    for (int r = 1; r < rows; r++) {
      final y = offsetY + r * cellH;
      canvas.drawLine(Offset(offsetX, y), Offset(offsetX + cols * cellW, y), gridPaint);
    }

    // [선택] 메이저 그리드(예: 5칸마다 두껍게)
    // const majorStep = 5;
    // final major = Paint()..color = const Color(0xFF000000)..strokeWidth = 2.0;
    // for (int c = majorStep; c < cols; c += majorStep) {
    //   final x = offsetX + c * cellW;
    //   canvas.drawLine(Offset(x, offsetY), Offset(x, offsetY + rows * cellH), major);
    // }
    // for (int r = majorStep; r < rows; r += majorStep) {
    //   final y = offsetY + r * cellH;
    //   canvas.drawLine(Offset(offsetX, y), Offset(offsetX + cols * cellW, y), major);
    // }
  }

  @override
  bool shouldRepaint(covariant _GridPainter old) =>
      old.rows != rows ||
          old.cols != cols ||
          old.cellW != cellW ||
          old.cellH != cellH ||
          old.offsetX != offsetX ||
          old.offsetY != offsetY;
}

class _CellTappableArea extends StatelessWidget {
  const _CellTappableArea({
    required this.rows,
    required this.cols,
    required this.cellW,
    required this.cellH,
    required this.offsetX,
    required this.offsetY,
    required this.onCellTap,
  });

  final int rows;
  final int cols;
  final double cellW;
  final double cellH;
  final double offsetX;
  final double offsetY;
  final void Function(int row, int col) onCellTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (d) {
        final box = context.findRenderObject() as RenderBox?;
        if (box == null) return;
        final local = box.globalToLocal(d.globalPosition);

        // 그리드 내 좌표인지 검사 (고정모드에서 바깥 여백 클릭 방지)
        final minX = offsetX;
        final minY = offsetY;
        final maxX = offsetX + cols * cellW;
        final maxY = offsetY + rows * cellH;
        if (local.dx < minX || local.dx >= maxX || local.dy < minY || local.dy >= maxY) {
          return; // 그리드 밖이면 무시
        }

        final relX = local.dx - offsetX;
        final relY = local.dy - offsetY;

        int c = (relX / cellW).floor().clamp(0, cols - 1);
        int r = (relY / cellH).floor().clamp(0, rows - 1);
        onCellTap(r, c);
      },
    );
  }
}
